import inquirer from "inquirer";
const answer = await inquirer.prompt([
    { message: "Enter 1st No.", type: "number", name: "firstNumber" },
    { message: "Enter 2nd No.", type: "number", name: "secondNumber" },
    {
        message: "Select Operation",
        type: "list",
        name: "Operator",
        choices: ["+", "-", "*", "/"],
    },
]);
// console.log(answer);
if (answer.Operator === "+") {
    console.log(answer.firstNumber + answer.secondNumber);
}
else if (answer.Operator === "-") {
    console.log(answer.firstNumber - answer.secondNumber);
}
else if (answer.Operator === "*") {
    console.log(answer.firstNumber * answer.secondNumber);
}
else if (answer.Operator === "/") {
    console.log(answer.firstNumber / answer.secondNumber);
}
else {
    console.log("Invalid Operator!");
}
